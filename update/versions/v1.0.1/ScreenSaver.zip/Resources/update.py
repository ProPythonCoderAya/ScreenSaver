import json
import re

import requests
import os

class UpdateChecker:
    def __init__(self, gituser, gitrepo, gitrepoversionfile, localversionfile):
        self.user = gituser
        self.repo = gitrepo
        self.version_git = gitrepoversionfile
        self.version_local = localversionfile
        self.url = f"https://raw.githubusercontent.com/{gituser}/{gitrepo}/main/{gitrepoversionfile}"

    @staticmethod
    def is_valid_version(version):
        return bool(re.compile(r"^v\d+(\.\d+){0,2}$").match(version))

    def __fetch(self):
        """ Fetches the remote version file """
        response = requests.get(self.url)
        if response.status_code == 200:
            return response.json()
        else:
            print(f"Error while fetching from {self.url}, status code: {response.status_code}")

    def __local(self):
        if os.path.exists(self.version_local):
            try:
                with open(self.version_local) as f:
                    data = json.load(f)

                version: str = data["version"]

                if not self.is_valid_version(version):
                    print("Version is corrupted")
                else:
                    return version

            except Exception as e:
                print(f"Failed to load local version: {e}")

        version = "v0.0.0"
        with open(self.version_local, "w") as f:
            json.dump({"version": version}, f, indent=4)
        return version

    def check(self) -> tuple[bool, str, str]:
        local_version = self.__local()
        remote_version = self.__fetch()["version"]

        return local_version != remote_version, local_version, remote_version


__all__ = [
    "UpdateChecker"
]
